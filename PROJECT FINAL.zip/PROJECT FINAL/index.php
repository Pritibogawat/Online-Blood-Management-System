<?php
include("Connection.php");

?>

<html>
<head>
<title>LOGIN FORM</title>
<link rel="stylesheet" type="text/css" href="pplogin.css">
</head>
<body>
 <div class="login-box">
 <h1>LOGIN HERE</h1>
 <form action="Loginpost.php" method="post">
 <p>Username</p>
 <input type="text" name="username" placeholder="Enter username" required>
 <p>Password</p>
 <input type="password" name="password" placeholder="Enter password" required>
 <br><br>
 <input type="submit" name="submit" value="LOGIN"><br>
 <a href="ppregistration.html">NEW USER?</a>
 
 </form>
 </div>
</body>
</html>
