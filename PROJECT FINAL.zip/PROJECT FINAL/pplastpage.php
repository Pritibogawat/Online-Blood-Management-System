<html>
<head>
<title>last Page</title>
<link rel="stylesheet" type="text/css" href="pplastpage.css">
</head>
<body>
<div class="login-box">
<form action="Logout.php" method="post">
<p><h2>Thank You.</h2></p>
<h3>Your request is successfully registered. Please visit the respective blood bank.</h3>
<input type="submit" name="submit" value="LOGOUT"><br>
</form>
</div>
</body>
</html>





<!--html>
<head>
<title>last Page</title>
<link rel="stylesheet" type="text/css" href="pplastpage.css">
</head>
<body>
<div class="login-box">
<p><h2>Thank You.</h2></p>
<h3>Your request is successfully registered. Please visit the respective blood bank.</h3>
</body>
</html-->