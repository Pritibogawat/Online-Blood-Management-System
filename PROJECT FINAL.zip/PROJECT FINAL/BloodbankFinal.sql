-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 22, 2020 at 10:41 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `l_id` int(50) NOT NULL,
  `s_id` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`l_id`, `s_id`, `username`, `password`) VALUES
(1, 1, '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `d_id` int(50) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `d_age` varchar(50) NOT NULL,
  `d_weight` varchar(50) NOT NULL,
  `d_address` varchar(50) NOT NULL,
  `d_mobno` varchar(50) NOT NULL,
  `d_bgroup` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`d_id`, `d_name`, `d_age`, `d_weight`, `d_address`, `d_mobno`, `d_bgroup`) VALUES
(1, 'Pratiksha Ghate', '18', '44', 'pune', '1234543436', 'A+'),
(2, 'adads', '21212', '2121', 'dad', '1234543436', 'A+'),
(3, 'Python', '232', '2323', 'dfg', '3232334343', 'O+'),
(4, 'pp', '12', '1212', 'pune', '1234543436', 'A+'),
(5, 'GHATE PRATHAMESH VINAYANK', '13', '33', 'pune', '1234543436', 'A+'),
(6, 'Python', '33', '323', 'pune', '1234543436', 'AB+'),
(7, 'GHATE PRATHAMESH VINAYANK', '45', '45', 'pune', '1234543436', 'A+');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `l_id` int(50) NOT NULL,
  `r_id` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`l_id`, `r_id`, `username`, `password`) VALUES
(1, 4, 'a', 'a'),
(2, 5, 'admin', 'admin'),
(3, 7, 'pratiksha', 'trtr');

-- --------------------------------------------------------

--
-- Table structure for table `receiver`
--

CREATE TABLE `receiver` (
  `r_id` int(50) NOT NULL,
  `r_name` varchar(50) NOT NULL,
  `r_age` varchar(50) NOT NULL,
  `r_weight` varchar(50) NOT NULL,
  `r_address` varchar(50) NOT NULL,
  `r_mobno` varchar(50) NOT NULL,
  `r_bgroup` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receiver`
--

INSERT INTO `receiver` (`r_id`, `r_name`, `r_age`, `r_weight`, `r_address`, `r_mobno`, `r_bgroup`) VALUES
(2, 'Pratiksha Ghate', '12', '44', 'pune', '1234543436', 'A+');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `r_id` int(50) NOT NULL,
  `r_name` varchar(50) NOT NULL,
  `r_address` varchar(50) NOT NULL,
  `r_mobno` varchar(50) NOT NULL,
  `r_bgroup` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`r_id`, `r_name`, `r_address`, `r_mobno`, `r_bgroup`) VALUES
(1, 'Pratiksha Ghate', 'PUNE', '1234567898', 'A+'),
(2, 'Pratiksha Ghate', 'PUNE', '1234567898', 'A+'),
(3, 'Pratiksha Ghate', 'pune', '1234567898', 'A+'),
(4, 'Pratiksha Ghate', 'pune', '1234567898', 'A+'),
(5, 'Admin', 'Pune', '1234567898', 'A+'),
(6, 'Admin', 'Pune', '1234567898', 'A+'),
(7, 'Python', 'gfdgdf', '1234567898', 'A+');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `receiver`
--
ALTER TABLE `receiver`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`r_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donor`
--
ALTER TABLE `donor`
  MODIFY `d_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `l_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `receiver`
--
ALTER TABLE `receiver`
  MODIFY `r_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `r_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
