<?php
include("Connection.php");
?>

<html>
<head>
<title>USER FORM</title>
<link rel="stylesheet" type="text/css" href="ppuser.css">
</head>
<body>
<center>
 <div class="login-box">
<h1><b><a href="Donor.php">Are you a donor?</a></b><br>
<b><a href="Receiver.php">Are you a receiver?</a></b></h1>
</center>
</div>
</form>
</body>
</html>