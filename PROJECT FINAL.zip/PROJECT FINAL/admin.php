<?php
$a=$_POST['username'];
$b=$_POST['password'];
if(username==$a && password==$b)
{


}

