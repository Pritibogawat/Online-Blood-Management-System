<?php
include("Connection.php");
$name=$_POST['name'];
$age=$_POST['age'];
$weight=$_POST['weight'];
$address=$_POST['address'];
$mob=$_POST['mobno'];
$group=$_POST['group'];

$is_insert = true;
$stock = 0;
$q_check = "select (SELECT count(*) as counts FROM `donor` where d_bgroup='".$group."' group by `d_bgroup`) - (SELECT count(*) as counts FROM `receiver` where r_bgroup='".$group."' group by `r_bgroup`) as counts";
$re = mysqli_query($conn,$q_check);
while($a=mysqli_fetch_array($re)){
	$stock = $a['counts'];
if($a['counts']<1){
												echo"<script> 
												alert('".$group." Blood is not in bank,stock is : ".$a['counts']."');
												window.location.href=('oops.php');
												</script>";

$is_insert= false;
//header("Location: Receiver.php"); 												
}
}
if($is_insert){
setcookie(c,$name);
setcookie(d,$group);

$query="insert into receiver(r_name,r_age,r_weight,r_address,r_mobno,r_bgroup) values('$name','$age','$weight','$address','$mob','$group')";
      if(mysqli_query($conn,$query))
		         
			      
                                             
			                      
				
										{
												echo"<script>
												alert('".$group." is available and stock is :".($stock-1)."');
												window.location.href=('re1.php');
						                                                </script>";
												
			
										}
							else{echo "Error";}			
									
}			 
		 
	?>

			 
	