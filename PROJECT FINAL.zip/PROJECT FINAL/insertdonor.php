<?php
include("Connection.php");
$name=$_POST['name'];
$age=$_POST['age'];
$weight=$_POST['weight'];
$address=$_POST['address'];
$mob=$_POST['mobno'];
$group=$_POST['group'];
setcookie(a,$name);
setcookie(b,$group);
$query="insert into donor(d_name,d_age,d_weight,d_address,d_mobno,d_bgroup) values('$name','$age','$weight','$address','$mob','$group')";
      if(mysqli_query($conn,$query))
		         
			      
                                             
			                      
				
										{
												echo"<script>
												alert('Records Inserted Successfully');
												window.location.href=('ppdonor.php');
                                                </script>";
												
			
										}
							else{echo "Error";}			
									
			 
		 
	?>

			 
	