<?php
include("Connection.php");
session_start();    
$user=$_POST['username'];
$pass=$_POST['password'];


$query = "select * from login where username='$user' and password='$pass' ";

$result=(mysqli_query($conn,$query));

if (mysqli_num_rows($result)>0)
{
	echo "<script>
	 alert ('Logged in successfully');
	 window.location.href=('ppuser.php');
	 </script>";
	 
$query1="select registration.r_id,r_name from registration inner join login  on registration.r_id=login.r_id and username='$user' and password='$pass' ";


$result1=(mysqli_query($conn,$query1));
while($row=mysqli_fetch_array($result1))
{
        $id=$row['r_id'];                                              
        $name=$row['r_name'];
       

                                                  
	  $_SESSION['r_id']=$id;
	  $_SESSION['r_name']=$name;
	  $_SESSION['username']=$user;
	  $_SESSION['password']=$pass;


       }
	 
	 
}	

else{
	echo "<script>
	alert('Invalid username or password');
	window.location.href=('index.php');
	</script>";
}

?>