<html>
<body>
<link rel="stylesheet" type="text/css" href="sample.css">
 <div class="login-box">
<?php
$a=$_POST['username'];
$b=$_POST['password'];
$c=$_POST['r'];
switch($c)
{
	case 1://echo "<form action=sample.php method=POST>";
		echo"<a href=ppuser.html>Please click here</a>";
	case 2:
		echo"<a href=ppuser.html>Please click here</a>";
	case 3: 
		echo"<a href=ppuser.html>Please click here</a>";
}
?>
</div>
</body>
</html>
