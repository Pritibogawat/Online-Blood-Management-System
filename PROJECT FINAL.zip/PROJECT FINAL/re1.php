<html>
<head>
<title>DONOR FORM</title>
<link rel="stylesheet" type="text/css" href="re1.css">
</head>
<body>
<div class="login-box">
<h1>Receiver Page</h1>
<form action="pplastpage.php" method="POST">
<h2>Your name is:</h2>
<?php
include("Connection.php");
echo $_COOKIE['c'];
?><br>
<h2>Your Blood Group:</h2>
<?php
include("Connection.php");
echo $_COOKIE['d'];
 ?> <br><br>
    <h2>Blood bank details are</h2><br>
    <h2>Name: Life blood Bank</h2><br>
    <h2>Address: katraj,Pune</h2><br>
    <h2>Contat Number:8983029647</h2><br>
<input type="submit" value="submit">
</div>
</form>
</body>
</html>