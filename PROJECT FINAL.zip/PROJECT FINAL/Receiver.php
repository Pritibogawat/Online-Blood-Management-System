<html>
<head>
<title>LOGIN FORM</title>
<link rel="stylesheet" type="text/css" href="ppregistration.css">
</head>
<body>
<form action="insertrece.php" method="POST">
 <div class="login-box">
<h1>Enter Receiver Details</h1>
<h3>
Name:
<input type="text" name="name" placeholder="Enter your Name" required><br>
Age:
<input type="number" name="age" placeholder="Enter your Age" required><br>
Weight:
<input type="number" name="weight" placeholder="Enter your Weight" required><br>

Adderss:<br><br>
<textarea name="address" placeholder="Enter your Adderss"  rows="2" cols="30" required></textarea><br><br>
Contact no:
<input type="text" name="mobno" placeholder="Enter your Contact no" minlength="10" maxlength="10" required><br>
Blood Group:
<select name="group">
<option value="A+">A+
<option value="A-">A-
<option value="B+">B+
<option value="B-">B-
<option value="AB+">AB+
<option value="AB-">AB-
<option value="O+">O+
<option value="O-">O-
</select><br><br>
<input type="submit" value="sign up"><br>
</h3>
</form>
</body>
</html>