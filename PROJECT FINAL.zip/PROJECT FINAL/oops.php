<html>
<head>
<title>last Page</title>
<link rel="stylesheet" type="text/css" href="oops.css">
</head>
<body>
<div class="login-box">
<form action="Logout.php" method="post">
<h2>Oops...</h2>
<h3>Sorry..Your requested blood is not available with us.</h3>
<h3>We will try getting it back as soon asc possible.</h3>
<h3>Thank you for visiting us.</h3>
<input type="submit" name="submit" value="LOGOUT"><br>
</form>
</div>
</body>
</html>