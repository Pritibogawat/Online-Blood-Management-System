<?php
include("Connection.php");

$name=$_POST['name'];
$mob=$_POST['no'];
$address=$_POST['address'];
$bgroup=$_POST['group'];
$username=$_POST['username'];
$password=$_POST['password'];



$query="insert into registration (r_name,r_address,r_mobno,r_bgroup) values('$name','$address','$mob','$bgroup')";

      if(mysqli_query($conn,$query))
		         {
                   echo $fk=mysqli_insert_id($conn);
			       
$query2="insert into login(r_id,username,password)values('$fk','$username','$password')";
								   if(mysqli_query($conn,$query2))
                                       
										{       echo"<script>
												alert('Records Inserted Successfully');
												window.location.href=('index.php');
                                                </script>";
										}
      
									else{
													echo "Error";
											}
      }
      
else{
													echo "Error";
											}

?>
			 
	