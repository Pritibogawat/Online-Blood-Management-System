<?php
$conn=mysqli_connect('localhost','root','');
$db=mysqli_select_db($conn,'bloodbank');
//echo"Connection Successfull";
?>