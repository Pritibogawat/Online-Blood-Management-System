<div class="col-md-2 bg-light"  style="height:1000px;text-align:center">




    
<br>
<!--<button class="btn btn-success btn-sm active" style="margin-left:-10px">Active</button>-->
<p><a href="showdonor.php" class="btn btn-dark  btn-lg" style="width:100%;padding:10px 20px;margin-top:200px">Donor Details</a></p>
<p><a href="showsreciver.php" class="btn btn-dark  btn-lg" style="width:100%;padding:10px 20px">Receiver Details</a></p>
<!--<p><a href="showcourse.php" class="btn btn-dark btn-lg" style="width:100%;padding:10px 20px">Course Details</a></p>-->

</div>