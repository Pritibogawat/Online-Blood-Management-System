<?php
include("Connection.php");
include("header.php");
?>

<div class="container-fluid">
<div  class="row">
    
<?php
include("sidebuttons.php");
?>

<div class="col-md-10 col-sm-10 col-xs-10 bg-light">
    <img src="img/data.jpg" style="background-attachment:fixed;background-position:center;background-repeat:no-repeat;width:100%;height:650px;margin-left:0%">
</div>


</div>
</div>

