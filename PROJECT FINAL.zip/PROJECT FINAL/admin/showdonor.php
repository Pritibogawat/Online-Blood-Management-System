<?php
include("Connection.php");
include("header.php");
?>

<div class="container-fluid">
<div  class="row">


<?php
include("Connection.php");
include("sidebuttons.php");
?>

<div class="col-md-10  bg-light"  style="height:500px;">

<h1>Donor Details</h1>
<table style="text-align:center;margin-left:50px;width:80%;margin-top:70px" class="table table-bordered">
 <thead>
<tr>
<th scope="col">Id</th>
<th scope="col">Name</th>
<th scope="col">Age</th>
<th scope="col">Weight</th>
<th scope="col">Address</th>
<th scope="col">bgroup</th>
</tr>
</thead>

<?php

include("Connection.php");

       $query="select * from donor";
  
  $result=mysqli_query($conn,$query);
  $i = 1;
  while($a=mysqli_fetch_array($result)){
	echo"<tbody>";
   echo"<tr>";
echo "<th scope='row'>".$i++."</th>";
echo "<td>".$a['d_name']."</td>";
echo "<td>".$a['d_age']."</td>";
echo"<td>".$a['d_weight']."</td>";
echo "<td>".$a['d_address']."</td>";
echo "<td>".$a['d_bgroup']."</td>";

// echo'<td>'."<a href='updatestaff.php?id=$a[st_id]' class='btn btn-primary'>Update</a>".'</td>';     
// echo'<td>'."<a href='deletestaff.php?id=$a[st_id]' class='btn btn-danger'>Delete</a>".'</td>';      
echo"</tr>";                                                                                                                                               
echo"</tbody>";

}

?>
</table>


</div>

</div>
</div>
