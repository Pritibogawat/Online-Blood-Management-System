<?php
include("Connection.php");

$name=$_POST['name'];
$mob=$_POST['mob'];
$email=$_POST['email'];
$gender=$_POST['option'];
$address=$_POST['address'];
$username=$_POST['username'];
$password=$_POST['password'];



$query="insert into user_details(s_name,s_mobno,s_email,s_gender,s_address) values('$name','$mob','$email','$gender','$address')";
      if(mysqli_query($conn,$query))
		         {
                   
								  
					$query2="insert into login(s_id,username,password)values('$fk','$username','$password')";
								   if(mysqli_query($conn,$query2))
										{       echo"<script>
												alert('Records Inserted Successfully');
												window.location.href=('index.php');
                                                </script>";
										}
										
									else{
													echo "Error";
											}
      }
									
		
		   else{
			 echo "Error";
		 }

?>
			 
	