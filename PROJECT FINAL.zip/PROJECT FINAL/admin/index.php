<!DOCTYPE html>
<html>
<head>
<title>DashBoard</title>
<meta lang='Eng'>
<meta utf-8>
<meta name="contain"  content="width=device-width , initial-scale=1">
    
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<link href="style.css" rel="stylesheet" type="text/css">
	<link rel="icon" href="img/user9.png" >
    
</head>

<body style="background-image:url(img/bg9.jpeg);">

<div class="container">
<div class="row">
    
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12"></div>
    
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 text-center">
<form  name="myForm" action="Loginpost.php" method="post" id="FL" class="was-validated text-center" style="margin-top:150px;background-color:#f7f2f7;opacity:11">

    <img src="img/user3.png" style="height:100px;width:100px;margin-top:-150px;border-radius:100%;border:2px solid #fff">

    <h1 style="color:darkslategrey;">Login</h1>
    
    
<div class="form-group">
<label style="color:black; float:left">Enter Username:</label>
<input type="text" name="username" placeholder="admin" class="form-control" required>

<label style="color:black; float:left">Enter Password:</label>
<input type="password" name="password" placeholder="admin" class="form-control">
</div>

<a href="form.php" style="height:45px;text-align:center" class="btn btn-warning">Sign Up</a>
<input type="submit" value="Login" class="btn btn-success" style="height:45px;color:black">
    
    

</form>
</div>


<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12"></div>
</div>
</div>
</body>
</html>